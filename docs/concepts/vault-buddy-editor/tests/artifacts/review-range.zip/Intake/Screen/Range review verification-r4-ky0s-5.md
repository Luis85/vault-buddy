---
title: "Range review verification · Review 1"
type: video-tutorial
project_id: "tutorial-multitrack-demo"
project_revision: 4
product_id: "product-mu8gky0s-5"
rendered_at: "2026-09-19T14:04:20.669Z"
duration_seconds: 1.600
source_range_start_seconds: 1.000
source_range_end_seconds: 2.600
---

# Range review verification · Review 1

![[Range review verification-r4-ky0s-5.webm]]

## Chapters

No chapter starts in this rendered range.

## Editable project

This product was rendered from **Range review verification**, revision **4**. Open its saved .vbproject.zip or .vbproject.json to continue editing.

The exported video is not the editable workspace. Original captures are not included in this output package.
