---
title: "Workspace roundtrip test · Review 1"
type: video-tutorial
project_id: "verified-workspace"
project_revision: 1
product_id: "product-mu8gjfqo-i"
rendered_at: "2026-09-19T14:03:10.320Z"
duration_seconds: 2.600
source_range_start_seconds: 0.000
source_range_end_seconds: 2.600
---

# Workspace roundtrip test · Review 1

![[Workspace roundtrip test-r1-jfqo-i.webm]]

## Chapters

No chapter starts in this rendered range.

## Editable project

This product was rendered from **Workspace roundtrip test**, revision **1**. Open its saved .vbproject.zip or .vbproject.json to continue editing.

The exported video is not the editable workspace. Original captures are not included in this output package.
